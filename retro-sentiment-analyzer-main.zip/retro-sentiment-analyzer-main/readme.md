This app is for AGILE coach or Scrum Masters to understand how their team is feeling after their retrospective sessions.
